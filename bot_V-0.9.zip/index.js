/* global member */

const Discord = require('discord.js');
const { prefix, token } = require('./config.json');
const client = new Discord.Client();

client.once('ready', () => {
    console.log('Ready!');
});
client.on('message', message => {
    if (message.content === '!thomashelp') {
        message.channel.send(
                'Jelenleg elérhető parancsok' + '\n' + '\n'
                + '- !thomashelp = Segítség kérés' + '\n'
                + '- !thomasoltás = Thomas beszól neked valamit.' + '\n'
                + '- !hullámvasút @username = Felültetsz vele valakit a Thomasra.'+'\n'
                + '- !tsound "effect_száma" = Lejátszasz egy hang effectet! effectek listájához írd be a "!tsoundlist"-parancsot!');
    }
    else if (message.content === '!thomasoltás') {
        message.channel.send('Mi kéne te fasz?');
    }
    else if (message.content === '!tsoundlist') {
        message.channel.send('1 - bruhh '+'\n'
                            +'2 - oh no'+'\n'
                            +'3 - no god'+'\n'
                            +'4 - why are you runnin'+'\n'
                            +'5 - dam boy');
    }
    else if (message.content === '!tsound 1') {
        message.channel.send('Fejlesztés alatt');
    }
    else if (message.content.includes("!hullámvasút")) {
        const taggedUser = message.mentions.users.first();
        message.channel.send(`Thomas elvitte : ${taggedUser} egy körre.`);
        taggedUser.voice.setChannel([830749958856114187],["Jegyeket bérleteket!"]);
    }
    

});

client.login('ODMwNzUzMzY0NDY2OTkxMTI1.YHLRXA.8CDV0SaSGKH-vjiLWR-mj4ThZbQ');