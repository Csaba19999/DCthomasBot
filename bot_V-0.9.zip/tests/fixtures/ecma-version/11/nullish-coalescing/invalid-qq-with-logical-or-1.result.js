module.exports = {
    "index": 7,
    "lineNumber": 1,
    "column": 8,
    "message": "Logical expressions and coalesce expressions cannot be mixed. Wrap either by parentheses"
};