module.exports = {
    "index": 12,
    "lineNumber": 1,
    "column": 13,
    "message": "'import.meta' must not contain escaped characters"
};