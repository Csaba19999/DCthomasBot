const url = import.\u006d\u0065\u0074\u0061.url
