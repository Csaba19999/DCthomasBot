module.exports = {
    "index": 19,
    "lineNumber": 1,
    "column": 20,
    "message": "The only valid meta property for import is 'import.meta'"
};