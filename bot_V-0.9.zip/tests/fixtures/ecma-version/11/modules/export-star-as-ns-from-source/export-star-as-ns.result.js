module.exports = {
    "type": "Program",
    "loc": {
        "start": {
            "line": 1,
            "column": 0
        },
        "end": {
            "line": 1,
            "column": 28
        }
    },
    "range": [
        0,
        28
    ],
    "body": [
        {
            "type": "ExportAllDeclaration",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 0
                },
                "end": {
                    "line": 1,
                    "column": 28
                }
            },
            "range": [
                0,
                28
            ],
            "exported": {
                "type": "Identifier",
                "loc": {
                    "start": {
                        "line": 1,
                        "column": 12
                    },
                    "end": {
                        "line": 1,
                        "column": 14
                    }
                },
                "range": [
                    12,
                    14
                ],
                "name": "ns"
            },
            "source": {
                "type": "Literal",
                "loc": {
                    "start": {
                        "line": 1,
                        "column": 20
                    },
                    "end": {
                        "line": 1,
                        "column": 28
                    }
                },
                "range": [
                    20,
                    28
                ],
                "value": "source",
                "raw": "\"source\""
            }
        }
    ],
    "sourceType": "module",
    "tokens": [
        {
            "type": "Keyword",
            "value": "export",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 0
                },
                "end": {
                    "line": 1,
                    "column": 6
                }
            },
            "range": [
                0,
                6
            ]
        },
        {
            "type": "Punctuator",
            "value": "*",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 7
                },
                "end": {
                    "line": 1,
                    "column": 8
                }
            },
            "range": [
                7,
                8
            ]
        },
        {
            "type": "Identifier",
            "value": "as",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 9
                },
                "end": {
                    "line": 1,
                    "column": 11
                }
            },
            "range": [
                9,
                11
            ]
        },
        {
            "type": "Identifier",
            "value": "ns",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 12
                },
                "end": {
                    "line": 1,
                    "column": 14
                }
            },
            "range": [
                12,
                14
            ]
        },
        {
            "type": "Identifier",
            "value": "from",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 15
                },
                "end": {
                    "line": 1,
                    "column": 19
                }
            },
            "range": [
                15,
                19
            ]
        },
        {
            "type": "String",
            "value": "\"source\"",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 20
                },
                "end": {
                    "line": 1,
                    "column": 28
                }
            },
            "range": [
                20,
                28
            ]
        }
    ]
};