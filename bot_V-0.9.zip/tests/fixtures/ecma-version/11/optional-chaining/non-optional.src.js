(obj.aaa).bbb;
(obj.aaa)()
