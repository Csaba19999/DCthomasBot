for (obj?.foo in {}) ;
