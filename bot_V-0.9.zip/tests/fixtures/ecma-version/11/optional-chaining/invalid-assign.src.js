obj?.foo = 0
