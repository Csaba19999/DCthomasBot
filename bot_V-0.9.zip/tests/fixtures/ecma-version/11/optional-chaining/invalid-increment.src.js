obj?.foo++
