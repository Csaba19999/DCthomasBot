(obj.aaa)?.bbb
