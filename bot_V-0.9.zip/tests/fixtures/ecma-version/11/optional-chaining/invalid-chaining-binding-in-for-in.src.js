for (obj?.foo.bar in {}) ;
