new obj?.foo()
