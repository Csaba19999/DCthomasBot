new obj?.()
