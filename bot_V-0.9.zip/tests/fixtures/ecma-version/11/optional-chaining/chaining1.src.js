obj?.aaa.bbb
