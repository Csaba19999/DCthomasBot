obj?.foo.bar++
