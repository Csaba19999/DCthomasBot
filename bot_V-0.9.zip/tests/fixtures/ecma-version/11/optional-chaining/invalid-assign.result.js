module.exports = {
    "index": 0,
    "lineNumber": 1,
    "column": 1,
    "message": "Optional chaining cannot appear in left-hand side"
};