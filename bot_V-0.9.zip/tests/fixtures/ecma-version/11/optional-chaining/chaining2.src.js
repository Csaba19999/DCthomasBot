obj.aaa?.bbb
