module.exports = {
    "index": 10,
    "lineNumber": 1,
    "column": 11,
    "message": "Unexpected token =>"
};