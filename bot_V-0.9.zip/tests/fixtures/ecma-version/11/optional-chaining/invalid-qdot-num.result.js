module.exports = {
    "index": 7,
    "lineNumber": 2,
    "column": 1,
    "message": "Unexpected token"
};