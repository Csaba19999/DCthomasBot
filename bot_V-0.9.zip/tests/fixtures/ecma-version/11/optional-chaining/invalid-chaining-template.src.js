obj?.tag`template`
