module.exports = {
    "index": 5,
    "lineNumber": 1,
    "column": 6,
    "message": "Optional chaining cannot appear in left-hand side"
};