(obj?.aaa).bbb
