obj?.foo.bar = 0
