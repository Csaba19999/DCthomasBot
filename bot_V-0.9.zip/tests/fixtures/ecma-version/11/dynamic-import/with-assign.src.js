import(source = "foo.js")
