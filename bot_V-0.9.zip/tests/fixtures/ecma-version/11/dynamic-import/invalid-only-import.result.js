module.exports = {
    "index": 17,
    "lineNumber": 2,
    "column": 1,
    "message": "Unexpected token"
};