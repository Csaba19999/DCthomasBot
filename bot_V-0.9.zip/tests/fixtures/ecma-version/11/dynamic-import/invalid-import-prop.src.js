const i = import.property
