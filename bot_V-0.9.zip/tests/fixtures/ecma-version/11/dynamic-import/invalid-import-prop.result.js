module.exports = {
    "index": 17,
    "lineNumber": 1,
    "column": 18,
    "message": "The only valid meta property for import is 'import.meta'"
};