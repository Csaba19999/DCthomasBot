async function main() {
    const foo = await import(source)
}
