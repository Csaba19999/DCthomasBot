module.exports = {
    "index": 4,
    "lineNumber": 1,
    "column": 5,
    "message": "Cannot use new with import()"
};