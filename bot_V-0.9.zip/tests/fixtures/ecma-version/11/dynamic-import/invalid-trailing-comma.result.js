module.exports = {
    "index": 13,
    "lineNumber": 1,
    "column": 14,
    "message": "Trailing comma is not allowed in import()"
};