module.exports = {
    "index": 3,
    "lineNumber": 1,
    "column": 4,
    "message": "Identifier directly after number"
};