module.exports = {
    "type": "Program",
    "loc": {
        "start": {
            "line": 1,
            "column": 0
        },
        "end": {
            "line": 1,
            "column": 2
        }
    },
    "range": [
        0,
        2
    ],
    "body": [
        {
            "type": "ExpressionStatement",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 0
                },
                "end": {
                    "line": 1,
                    "column": 2
                }
            },
            "range": [
                0,
                2
            ],
            "expression": {
                "type": "Literal",
                "loc": {
                    "start": {
                        "line": 1,
                        "column": 0
                    },
                    "end": {
                        "line": 1,
                        "column": 2
                    }
                },
                "range": [
                    0,
                    2
                ],
                "value": 1n,
                "raw": "1n",
                "bigint": "1"
            }
        }
    ],
    "sourceType": "script",
    "tokens": [
        {
            "type": "Numeric",
            "value": "1n",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 0
                },
                "end": {
                    "line": 1,
                    "column": 2
                }
            },
            "range": [
                0,
                2
            ]
        }
    ]
};
