module.exports = {
    "type": "Program",
    "loc": {
        "start": {
            "line": 1,
            "column": 0
        },
        "end": {
            "line": 1,
            "column": 7
        }
    },
    "range": [
        0,
        7
    ],
    "body": [
        {
            "type": "ExpressionStatement",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 0
                },
                "end": {
                    "line": 1,
                    "column": 7
                }
            },
            "range": [
                0,
                7
            ],
            "expression": {
                "type": "Literal",
                "loc": {
                    "start": {
                        "line": 1,
                        "column": 0
                    },
                    "end": {
                        "line": 1,
                        "column": 7
                    }
                },
                "range": [
                    0,
                    7
                ],
                "value": 0b0101n,
                "raw": "0b0101n",
                "bigint": "0b0101"
            }
        }
    ],
    "sourceType": "script",
    "tokens": [
        {
            "type": "Numeric",
            "value": "0b0101n",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 0
                },
                "end": {
                    "line": 1,
                    "column": 7
                }
            },
            "range": [
                0,
                7
            ]
        }
    ]
};
