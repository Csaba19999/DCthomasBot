module.exports = {
    "index": 3,
    "lineNumber": 1,
    "column": 4,
    "message": "Numeric separator is not allowed at the last of digits"
};