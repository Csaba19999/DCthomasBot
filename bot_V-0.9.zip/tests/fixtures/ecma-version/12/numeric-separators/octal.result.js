module.exports = {
    "type": "Program",
    "loc": {
        "start": {
            "line": 1,
            "column": 0
        },
        "end": {
            "line": 1,
            "column": 9
        }
    },
    "range": [
        0,
        9
    ],
    "body": [
        {
            "type": "ExpressionStatement",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 0
                },
                "end": {
                    "line": 1,
                    "column": 9
                }
            },
            "range": [
                0,
                9
            ],
            "expression": {
                "type": "Literal",
                "loc": {
                    "start": {
                        "line": 1,
                        "column": 0
                    },
                    "end": {
                        "line": 1,
                        "column": 9
                    }
                },
                "range": [
                    0,
                    9
                ],
                "value": 0o755666,
                "raw": "0o755_666"
            }
        }
    ],
    "sourceType": "script",
    "tokens": [
        {
            "type": "Numeric",
            "value": "0o755_666",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 0
                },
                "end": {
                    "line": 1,
                    "column": 9
                }
            },
            "range": [
                0,
                9
            ]
        }
    ]
};
