module.exports = {
    "index": 2,
    "lineNumber": 1,
    "column": 3,
    "message": "Numeric separator is not allowed at the first of digits"
};