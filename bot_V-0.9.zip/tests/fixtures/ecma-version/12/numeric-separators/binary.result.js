module.exports = {
    "type": "Program",
    "loc": {
        "start": {
            "line": 1,
            "column": 0
        },
        "end": {
            "line": 1,
            "column": 11
        }
    },
    "range": [
        0,
        11
    ],
    "body": [
        {
            "type": "ExpressionStatement",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 0
                },
                "end": {
                    "line": 1,
                    "column": 11
                }
            },
            "range": [
                0,
                11
            ],
            "expression": {
                "type": "Literal",
                "loc": {
                    "start": {
                        "line": 1,
                        "column": 0
                    },
                    "end": {
                        "line": 1,
                        "column": 11
                    }
                },
                "range": [
                    0,
                    11
                ],
                "value": 0b01011010,
                "raw": "0b0101_1010"
            }
        }
    ],
    "sourceType": "script",
    "tokens": [
        {
            "type": "Numeric",
            "value": "0b0101_1010",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 0
                },
                "end": {
                    "line": 1,
                    "column": 11
                }
            },
            "range": [
                0,
                11
            ]
        }
    ]
};
