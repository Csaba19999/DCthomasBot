a ||= b
