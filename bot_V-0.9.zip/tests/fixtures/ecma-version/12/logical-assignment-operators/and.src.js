a &&= b
