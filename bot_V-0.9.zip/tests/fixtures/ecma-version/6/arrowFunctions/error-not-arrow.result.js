module.exports = {
    "index": 26,
    "lineNumber": 1,
    "column": 27,
    "message": "Unexpected token )"
};