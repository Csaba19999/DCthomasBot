module.exports = {
    "index": 21,
    "lineNumber": 1,
    "column": 22,
    "message": "Invalid number"
};