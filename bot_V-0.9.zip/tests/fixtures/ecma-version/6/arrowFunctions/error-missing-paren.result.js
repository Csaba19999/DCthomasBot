module.exports = {
    "index": 4,
    "lineNumber": 1,
    "column": 5,
    "message": "Parenthesized pattern"
};
