module.exports = {
    "index": 18,
    "lineNumber": 1,
    "column": 19,
    "message": "Argument name clash"
};