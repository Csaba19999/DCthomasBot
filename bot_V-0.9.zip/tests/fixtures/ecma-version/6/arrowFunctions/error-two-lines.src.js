var a = ()
	=> 0;