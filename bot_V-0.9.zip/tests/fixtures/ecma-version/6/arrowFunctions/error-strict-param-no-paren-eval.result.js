module.exports = {
    "index": 14,
    "lineNumber": 1,
    "column": 15,
    "message": "Binding eval in strict mode"
};