module.exports = {
    "index": 15,
    "lineNumber": 1,
    "column": 16,
    "message": "Binding arguments in strict mode"
};