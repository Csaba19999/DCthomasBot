class A extends B {
    constructor(){
        super();
    }
};
