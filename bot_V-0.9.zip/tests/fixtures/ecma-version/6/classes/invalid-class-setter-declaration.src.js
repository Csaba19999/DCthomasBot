class A { set foo() {}};
