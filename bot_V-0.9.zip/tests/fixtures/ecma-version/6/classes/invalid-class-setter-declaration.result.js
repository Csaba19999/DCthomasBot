module.exports = {
    "index": 17,
    "lineNumber": 1,
    "column": 18,
    "message": "setter should have exactly one param"
};