class A {
    a(){}
};