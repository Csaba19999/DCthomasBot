let foo = bar;
