const foo = bar;
