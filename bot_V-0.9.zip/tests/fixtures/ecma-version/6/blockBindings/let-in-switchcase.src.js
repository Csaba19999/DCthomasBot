switch (answer) { case 42: let t = 42; break; }
