class Foo {
	static *bar() {
	}
}