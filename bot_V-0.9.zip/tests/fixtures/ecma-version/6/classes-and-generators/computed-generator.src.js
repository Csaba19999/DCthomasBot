class Foo {
	*[Symbol.iterator]() {
	}
}
