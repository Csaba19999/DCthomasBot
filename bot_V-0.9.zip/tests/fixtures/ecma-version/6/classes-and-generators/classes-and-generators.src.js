class Foo {
	*bar() {
	}
}