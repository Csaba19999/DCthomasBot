var s = " "
