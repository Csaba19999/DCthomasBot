var s = " "
