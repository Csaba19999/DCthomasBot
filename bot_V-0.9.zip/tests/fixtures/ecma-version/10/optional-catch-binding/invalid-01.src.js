try {
    foo()
} catch bar();
