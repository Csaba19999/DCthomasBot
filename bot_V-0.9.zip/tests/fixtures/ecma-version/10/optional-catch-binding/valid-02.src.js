try {
    foo()
} catch {
    bar()
}
