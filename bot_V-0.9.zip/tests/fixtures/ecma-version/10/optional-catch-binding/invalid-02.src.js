try {
    foo()
} catch () {}
