module.exports = {
    "index": 25,
    "lineNumber": 3,
    "column": 10,
    "message": "Unexpected token )"
};