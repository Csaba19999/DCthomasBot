module.exports = {
    "index": 24,
    "lineNumber": 3,
    "column": 9,
    "message": "Unexpected token bar"
};