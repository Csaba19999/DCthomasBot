function inner() {
    var private;
};