module.exports = {
    "type": "Program",
    "loc": {
        "start": {
            "line": 1,
            "column": 0
        },
        "end": {
            "line": 1,
            "column": 61
        }
    },
    "range": [
        0,
        61
    ],
    "body": [
        {
            "type": "ExpressionStatement",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 0
                },
                "end": {
                    "line": 1,
                    "column": 61
                }
            },
            "range": [
                0,
                61
            ],
            "expression": {
                "type": "JSXElement",
                "loc": {
                    "start": {
                        "line": 1,
                        "column": 0
                    },
                    "end": {
                        "line": 1,
                        "column": 60
                    }
                },
                "range": [
                    0,
                    60
                ],
                "openingElement": {
                    "type": "JSXOpeningElement",
                    "loc": {
                        "start": {
                            "line": 1,
                            "column": 0
                        },
                        "end": {
                            "line": 1,
                            "column": 60
                        }
                    },
                    "range": [
                        0,
                        60
                    ],
                    "attributes": [
                        {
                            "type": "JSXAttribute",
                            "loc": {
                                "start": {
                                    "line": 1,
                                    "column": 11
                                },
                                "end": {
                                    "line": 1,
                                    "column": 21
                                }
                            },
                            "range": [
                                11,
                                21
                            ],
                            "name": {
                                "type": "JSXIdentifier",
                                "loc": {
                                    "start": {
                                        "line": 1,
                                        "column": 11
                                    },
                                    "end": {
                                        "line": 1,
                                        "column": 15
                                    }
                                },
                                "range": [
                                    11,
                                    15
                                ],
                                "name": "left"
                            },
                            "value": {
                                "type": "JSXElement",
                                "loc": {
                                    "start": {
                                        "line": 1,
                                        "column": 16
                                    },
                                    "end": {
                                        "line": 1,
                                        "column": 21
                                    }
                                },
                                "range": [
                                    16,
                                    21
                                ],
                                "openingElement": {
                                    "type": "JSXOpeningElement",
                                    "loc": {
                                        "start": {
                                            "line": 1,
                                            "column": 16
                                        },
                                        "end": {
                                            "line": 1,
                                            "column": 21
                                        }
                                    },
                                    "range": [
                                        16,
                                        21
                                    ],
                                    "attributes": [],
                                    "name": {
                                        "type": "JSXIdentifier",
                                        "loc": {
                                            "start": {
                                                "line": 1,
                                                "column": 17
                                            },
                                            "end": {
                                                "line": 1,
                                                "column": 18
                                            }
                                        },
                                        "range": [
                                            17,
                                            18
                                        ],
                                        "name": "a"
                                    },
                                    "selfClosing": true
                                },
                                "closingElement": null,
                                "children": []
                            }
                        },
                        {
                            "type": "JSXAttribute",
                            "loc": {
                                "start": {
                                    "line": 1,
                                    "column": 22
                                },
                                "end": {
                                    "line": 1,
                                    "column": 57
                                }
                            },
                            "range": [
                                22,
                                57
                            ],
                            "name": {
                                "type": "JSXIdentifier",
                                "loc": {
                                    "start": {
                                        "line": 1,
                                        "column": 22
                                    },
                                    "end": {
                                        "line": 1,
                                        "column": 27
                                    }
                                },
                                "range": [
                                    22,
                                    27
                                ],
                                "name": "right"
                            },
                            "value": {
                                "type": "JSXElement",
                                "loc": {
                                    "start": {
                                        "line": 1,
                                        "column": 28
                                    },
                                    "end": {
                                        "line": 1,
                                        "column": 57
                                    }
                                },
                                "range": [
                                    28,
                                    57
                                ],
                                "openingElement": {
                                    "type": "JSXOpeningElement",
                                    "loc": {
                                        "start": {
                                            "line": 1,
                                            "column": 28
                                        },
                                        "end": {
                                            "line": 1,
                                            "column": 31
                                        }
                                    },
                                    "range": [
                                        28,
                                        31
                                    ],
                                    "attributes": [],
                                    "name": {
                                        "type": "JSXIdentifier",
                                        "loc": {
                                            "start": {
                                                "line": 1,
                                                "column": 29
                                            },
                                            "end": {
                                                "line": 1,
                                                "column": 30
                                            }
                                        },
                                        "range": [
                                            29,
                                            30
                                        ],
                                        "name": "b"
                                    },
                                    "selfClosing": false
                                },
                                "closingElement": {
                                    "type": "JSXClosingElement",
                                    "loc": {
                                        "start": {
                                            "line": 1,
                                            "column": 53
                                        },
                                        "end": {
                                            "line": 1,
                                            "column": 57
                                        }
                                    },
                                    "range": [
                                        53,
                                        57
                                    ],
                                    "name": {
                                        "type": "JSXIdentifier",
                                        "loc": {
                                            "start": {
                                                "line": 1,
                                                "column": 55
                                            },
                                            "end": {
                                                "line": 1,
                                                "column": 56
                                            }
                                        },
                                        "range": [
                                            55,
                                            56
                                        ],
                                        "name": "b"
                                    }
                                },
                                "children": [
                                    {
                                        "type": "JSXText",
                                        "loc": {
                                            "start": {
                                                "line": 1,
                                                "column": 31
                                            },
                                            "end": {
                                                "line": 1,
                                                "column": 53
                                            }
                                        },
                                        "range": [
                                            31,
                                            53
                                        ],
                                        "value": "monkeys /> gorillas",
                                        "raw": "monkeys /&gt; gorillas"
                                    }
                                ]
                            }
                        }
                    ],
                    "name": {
                        "type": "JSXIdentifier",
                        "loc": {
                            "start": {
                                "line": 1,
                                "column": 1
                            },
                            "end": {
                                "line": 1,
                                "column": 10
                            }
                        },
                        "range": [
                            1,
                            10
                        ],
                        "name": "LeftRight"
                    },
                    "selfClosing": true
                },
                "closingElement": null,
                "children": []
            }
        }
    ],
    "sourceType": "script",
    "tokens": [
        {
            "type": "Punctuator",
            "value": "<",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 0
                },
                "end": {
                    "line": 1,
                    "column": 1
                }
            },
            "range": [
                0,
                1
            ]
        },
        {
            "type": "JSXIdentifier",
            "value": "LeftRight",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 1
                },
                "end": {
                    "line": 1,
                    "column": 10
                }
            },
            "range": [
                1,
                10
            ]
        },
        {
            "type": "JSXIdentifier",
            "value": "left",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 11
                },
                "end": {
                    "line": 1,
                    "column": 15
                }
            },
            "range": [
                11,
                15
            ]
        },
        {
            "type": "Punctuator",
            "value": "=",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 15
                },
                "end": {
                    "line": 1,
                    "column": 16
                }
            },
            "range": [
                15,
                16
            ]
        },
        {
            "type": "Punctuator",
            "value": "<",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 16
                },
                "end": {
                    "line": 1,
                    "column": 17
                }
            },
            "range": [
                16,
                17
            ]
        },
        {
            "type": "JSXIdentifier",
            "value": "a",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 17
                },
                "end": {
                    "line": 1,
                    "column": 18
                }
            },
            "range": [
                17,
                18
            ]
        },
        {
            "type": "Punctuator",
            "value": "/",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 19
                },
                "end": {
                    "line": 1,
                    "column": 20
                }
            },
            "range": [
                19,
                20
            ]
        },
        {
            "type": "Punctuator",
            "value": ">",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 20
                },
                "end": {
                    "line": 1,
                    "column": 21
                }
            },
            "range": [
                20,
                21
            ]
        },
        {
            "type": "JSXIdentifier",
            "value": "right",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 22
                },
                "end": {
                    "line": 1,
                    "column": 27
                }
            },
            "range": [
                22,
                27
            ]
        },
        {
            "type": "Punctuator",
            "value": "=",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 27
                },
                "end": {
                    "line": 1,
                    "column": 28
                }
            },
            "range": [
                27,
                28
            ]
        },
        {
            "type": "Punctuator",
            "value": "<",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 28
                },
                "end": {
                    "line": 1,
                    "column": 29
                }
            },
            "range": [
                28,
                29
            ]
        },
        {
            "type": "JSXIdentifier",
            "value": "b",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 29
                },
                "end": {
                    "line": 1,
                    "column": 30
                }
            },
            "range": [
                29,
                30
            ]
        },
        {
            "type": "Punctuator",
            "value": ">",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 30
                },
                "end": {
                    "line": 1,
                    "column": 31
                }
            },
            "range": [
                30,
                31
            ]
        },
        {
            "type": "JSXText",
            "value": "monkeys /> gorillas",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 31
                },
                "end": {
                    "line": 1,
                    "column": 53
                }
            },
            "range": [
                31,
                53
            ]
        },
        {
            "type": "Punctuator",
            "value": "<",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 53
                },
                "end": {
                    "line": 1,
                    "column": 54
                }
            },
            "range": [
                53,
                54
            ]
        },
        {
            "type": "Punctuator",
            "value": "/",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 54
                },
                "end": {
                    "line": 1,
                    "column": 55
                }
            },
            "range": [
                54,
                55
            ]
        },
        {
            "type": "JSXIdentifier",
            "value": "b",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 55
                },
                "end": {
                    "line": 1,
                    "column": 56
                }
            },
            "range": [
                55,
                56
            ]
        },
        {
            "type": "Punctuator",
            "value": ">",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 56
                },
                "end": {
                    "line": 1,
                    "column": 57
                }
            },
            "range": [
                56,
                57
            ]
        },
        {
            "type": "Punctuator",
            "value": "/",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 58
                },
                "end": {
                    "line": 1,
                    "column": 59
                }
            },
            "range": [
                58,
                59
            ]
        },
        {
            "type": "Punctuator",
            "value": ">",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 59
                },
                "end": {
                    "line": 1,
                    "column": 60
                }
            },
            "range": [
                59,
                60
            ]
        },
        {
            "type": "Punctuator",
            "value": ";",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 60
                },
                "end": {
                    "line": 1,
                    "column": 61
                }
            },
            "range": [
                60,
                61
            ]
        }
    ]
};