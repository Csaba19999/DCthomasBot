module.exports = {
    "index": 27,
    "lineNumber": 1,
    "column": 28,
    "message": "Unexpected token {"
};