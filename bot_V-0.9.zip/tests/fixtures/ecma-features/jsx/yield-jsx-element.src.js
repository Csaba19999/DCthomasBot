function *foo() {
  yield <div>bar</div>;
}