module.exports = {
    "index": 9,
    "lineNumber": 1,
    "column": 10,
    "message": "Unexpected token ;"
};