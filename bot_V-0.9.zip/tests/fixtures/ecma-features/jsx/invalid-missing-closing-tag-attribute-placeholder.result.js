module.exports = {
    "index": 5,
    "lineNumber": 1,
    "column": 6,
    "message": "JSX attributes must only be assigned a non-empty expression"
};