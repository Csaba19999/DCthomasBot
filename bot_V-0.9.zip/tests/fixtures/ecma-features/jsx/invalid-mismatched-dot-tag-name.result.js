module.exports = {
    "index": 7,
    "lineNumber": 1,
    "column": 8,
    "message": "Expected corresponding JSX closing tag for <a.b.c>"
};