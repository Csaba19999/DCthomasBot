module.exports = {
    "index": 22,
    "lineNumber": 1,
    "column": 23,
    "message": "Adjacent JSX elements must be wrapped in an enclosing tag"
};