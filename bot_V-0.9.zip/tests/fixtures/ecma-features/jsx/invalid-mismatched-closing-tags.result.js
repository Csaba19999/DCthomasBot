module.exports = {
    "index": 8,
    "lineNumber": 1,
    "column": 9,
    "message": "Unterminated JSX contents"
};