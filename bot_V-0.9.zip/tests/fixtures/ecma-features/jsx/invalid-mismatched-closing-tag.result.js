module.exports = {
    "index": 3,
    "lineNumber": 1,
    "column": 4,
    "message": "Expected corresponding JSX closing tag for <a>"
};