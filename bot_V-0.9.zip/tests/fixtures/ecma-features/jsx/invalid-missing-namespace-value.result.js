module.exports = {
    "index": 5,
    "lineNumber": 1,
    "column": 6,
    "message": "Unterminated regular expression"
};