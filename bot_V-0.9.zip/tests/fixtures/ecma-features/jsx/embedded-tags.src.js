<LeftRight left=<a /> right=<b>monkeys /&gt; gorillas</b> />;
