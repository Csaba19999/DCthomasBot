module.exports = {
    "index": 4,
    "lineNumber": 1,
    "column": 5,
    "message": "Unexpected token :"
};
