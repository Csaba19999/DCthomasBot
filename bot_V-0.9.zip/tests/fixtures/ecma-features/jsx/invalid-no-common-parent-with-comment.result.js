module.exports = {
    "index": 49,
    "lineNumber": 1,
    "column": 50,
    "message": "Adjacent JSX elements must be wrapped in an enclosing tag"
};