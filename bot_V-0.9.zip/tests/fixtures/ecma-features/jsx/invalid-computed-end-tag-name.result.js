module.exports = {
    "index": 2,
    "lineNumber": 1,
    "column": 3,
    "message": "Unexpected token ["
};