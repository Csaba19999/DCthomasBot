module.exports = {
    "index": 5,
    "lineNumber": 1,
    "column": 6,
    "message": "Expected corresponding JSX closing tag for <a:b>"
};