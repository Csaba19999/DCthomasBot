module.exports = {
    "index": 6,
    "lineNumber": 1,
    "column": 7,
    "message": "Unexpected token props"
};