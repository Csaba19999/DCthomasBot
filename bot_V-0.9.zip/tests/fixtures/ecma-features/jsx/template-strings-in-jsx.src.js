<foo bar={`${baz}`} />
