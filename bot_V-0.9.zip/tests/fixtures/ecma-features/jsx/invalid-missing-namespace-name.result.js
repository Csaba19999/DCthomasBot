module.exports = {
    "index": 1,
    "lineNumber": 1,
    "column": 2,
    "message": "Unexpected token :"
};