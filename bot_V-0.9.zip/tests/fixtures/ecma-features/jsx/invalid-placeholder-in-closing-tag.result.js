module.exports = {
    "index": 16,
    "lineNumber": 1,
    "column": 17,
    "message": "Unexpected token {"
};