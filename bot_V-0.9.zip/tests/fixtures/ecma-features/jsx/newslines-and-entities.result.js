module.exports = {
    "index": 9,
    "lineNumber": 1,
    "column": 10,
    "message": "Expecting Unicode escape sequence \\uXXXX"
};