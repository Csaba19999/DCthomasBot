module.exports = {
    "index": 7,
    "lineNumber": 1,
    "column": 8,
    "message": "Unterminated string constant"
};