module.exports = {
    "index": 19,
    "lineNumber": 1,
    "column": 20,
    "message": "Unexpected token ,"
};