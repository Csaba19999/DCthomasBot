module.exports = {
    "index": 5,
    "lineNumber": 1,
    "column": 6,
    "message": "JSX value should be either an expression or a quoted JSX text"
};