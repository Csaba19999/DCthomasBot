<div {...props}>stuff</div {...props}>;
