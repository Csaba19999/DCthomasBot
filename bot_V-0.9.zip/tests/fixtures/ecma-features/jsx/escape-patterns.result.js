module.exports = {
    "type": "Program",
    "loc": {
        "start": {
            "line": 1,
            "column": 0
        },
        "end": {
            "line": 1,
            "column": 84
        }
    },
    "range": [
        0,
        84
    ],
    "body": [
        {
            "type": "ExpressionStatement",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 0
                },
                "end": {
                    "line": 1,
                    "column": 84
                }
            },
            "range": [
                0,
                84
            ],
            "expression": {
                "type": "JSXElement",
                "loc": {
                    "start": {
                        "line": 1,
                        "column": 0
                    },
                    "end": {
                        "line": 1,
                        "column": 83
                    }
                },
                "range": [
                    0,
                    83
                ],
                "openingElement": {
                    "type": "JSXOpeningElement",
                    "loc": {
                        "start": {
                            "line": 1,
                            "column": 0
                        },
                        "end": {
                            "line": 1,
                            "column": 83
                        }
                    },
                    "range": [
                        0,
                        83
                    ],
                    "attributes": [
                        {
                            "type": "JSXAttribute",
                            "loc": {
                                "start": {
                                    "line": 1,
                                    "column": 3
                                },
                                "end": {
                                    "line": 1,
                                    "column": 10
                                }
                            },
                            "range": [
                                3,
                                10
                            ],
                            "name": {
                                "type": "JSXIdentifier",
                                "loc": {
                                    "start": {
                                        "line": 1,
                                        "column": 3
                                    },
                                    "end": {
                                        "line": 1,
                                        "column": 4
                                    }
                                },
                                "range": [
                                    3,
                                    4
                                ],
                                "name": "b"
                            },
                            "value": {
                                "type": "JSXExpressionContainer",
                                "loc": {
                                    "start": {
                                        "line": 1,
                                        "column": 5
                                    },
                                    "end": {
                                        "line": 1,
                                        "column": 10
                                    }
                                },
                                "range": [
                                    5,
                                    10
                                ],
                                "expression": {
                                    "type": "Literal",
                                    "loc": {
                                        "start": {
                                            "line": 1,
                                            "column": 6
                                        },
                                        "end": {
                                            "line": 1,
                                            "column": 9
                                        }
                                    },
                                    "range": [
                                        6,
                                        9
                                    ],
                                    "value": " ",
                                    "raw": "\" \""
                                }
                            }
                        },
                        {
                            "type": "JSXAttribute",
                            "loc": {
                                "start": {
                                    "line": 1,
                                    "column": 11
                                },
                                "end": {
                                    "line": 1,
                                    "column": 16
                                }
                            },
                            "range": [
                                11,
                                16
                            ],
                            "name": {
                                "type": "JSXIdentifier",
                                "loc": {
                                    "start": {
                                        "line": 1,
                                        "column": 11
                                    },
                                    "end": {
                                        "line": 1,
                                        "column": 12
                                    }
                                },
                                "range": [
                                    11,
                                    12
                                ],
                                "name": "c"
                            },
                            "value": {
                                "type": "Literal",
                                "loc": {
                                    "start": {
                                        "line": 1,
                                        "column": 13
                                    },
                                    "end": {
                                        "line": 1,
                                        "column": 16
                                    }
                                },
                                "range": [
                                    13,
                                    16
                                ],
                                "value": " ",
                                "raw": "\" \""
                            }
                        },
                        {
                            "type": "JSXAttribute",
                            "loc": {
                                "start": {
                                    "line": 1,
                                    "column": 17
                                },
                                "end": {
                                    "line": 1,
                                    "column": 26
                                }
                            },
                            "range": [
                                17,
                                26
                            ],
                            "name": {
                                "type": "JSXIdentifier",
                                "loc": {
                                    "start": {
                                        "line": 1,
                                        "column": 17
                                    },
                                    "end": {
                                        "line": 1,
                                        "column": 18
                                    }
                                },
                                "range": [
                                    17,
                                    18
                                ],
                                "name": "d"
                            },
                            "value": {
                                "type": "Literal",
                                "loc": {
                                    "start": {
                                        "line": 1,
                                        "column": 19
                                    },
                                    "end": {
                                        "line": 1,
                                        "column": 26
                                    }
                                },
                                "range": [
                                    19,
                                    26
                                ],
                                "value": "&",
                                "raw": "\"&amp;\""
                            }
                        },
                        {
                            "type": "JSXAttribute",
                            "loc": {
                                "start": {
                                    "line": 1,
                                    "column": 27
                                },
                                "end": {
                                    "line": 1,
                                    "column": 43
                                }
                            },
                            "range": [
                                27,
                                43
                            ],
                            "name": {
                                "type": "JSXIdentifier",
                                "loc": {
                                    "start": {
                                        "line": 1,
                                        "column": 27
                                    },
                                    "end": {
                                        "line": 1,
                                        "column": 28
                                    }
                                },
                                "range": [
                                    27,
                                    28
                                ],
                                "name": "e"
                            },
                            "value": {
                                "type": "Literal",
                                "loc": {
                                    "start": {
                                        "line": 1,
                                        "column": 29
                                    },
                                    "end": {
                                        "line": 1,
                                        "column": 43
                                    }
                                },
                                "range": [
                                    29,
                                    43
                                ],
                                "value": "id=1&group=2",
                                "raw": "\"id=1&group=2\""
                            }
                        },
                        {
                            "type": "JSXAttribute",
                            "loc": {
                                "start": {
                                    "line": 1,
                                    "column": 44
                                },
                                "end": {
                                    "line": 1,
                                    "column": 59
                                }
                            },
                            "range": [
                                44,
                                59
                            ],
                            "name": {
                                "type": "JSXIdentifier",
                                "loc": {
                                    "start": {
                                        "line": 1,
                                        "column": 44
                                    },
                                    "end": {
                                        "line": 1,
                                        "column": 45
                                    }
                                },
                                "range": [
                                    44,
                                    45
                                ],
                                "name": "f"
                            },
                            "value": {
                                "type": "Literal",
                                "loc": {
                                    "start": {
                                        "line": 1,
                                        "column": 46
                                    },
                                    "end": {
                                        "line": 1,
                                        "column": 59
                                    }
                                },
                                "range": [
                                    46,
                                    59
                                ],
                                "value": "&#123456789",
                                "raw": "\"&#123456789\""
                            }
                        },
                        {
                            "type": "JSXAttribute",
                            "loc": {
                                "start": {
                                    "line": 1,
                                    "column": 60
                                },
                                "end": {
                                    "line": 1,
                                    "column": 71
                                }
                            },
                            "range": [
                                60,
                                71
                            ],
                            "name": {
                                "type": "JSXIdentifier",
                                "loc": {
                                    "start": {
                                        "line": 1,
                                        "column": 60
                                    },
                                    "end": {
                                        "line": 1,
                                        "column": 61
                                    }
                                },
                                "range": [
                                    60,
                                    61
                                ],
                                "name": "g"
                            },
                            "value": {
                                "type": "Literal",
                                "loc": {
                                    "start": {
                                        "line": 1,
                                        "column": 62
                                    },
                                    "end": {
                                        "line": 1,
                                        "column": 71
                                    }
                                },
                                "range": [
                                    62,
                                    71
                                ],
                                "value": "&#123*;",
                                "raw": "\"&#123*;\""
                            }
                        },
                        {
                            "type": "JSXAttribute",
                            "loc": {
                                "start": {
                                    "line": 1,
                                    "column": 72
                                },
                                "end": {
                                    "line": 1,
                                    "column": 80
                                }
                            },
                            "range": [
                                72,
                                80
                            ],
                            "name": {
                                "type": "JSXIdentifier",
                                "loc": {
                                    "start": {
                                        "line": 1,
                                        "column": 72
                                    },
                                    "end": {
                                        "line": 1,
                                        "column": 73
                                    }
                                },
                                "range": [
                                    72,
                                    73
                                ],
                                "name": "h"
                            },
                            "value": {
                                "type": "Literal",
                                "loc": {
                                    "start": {
                                        "line": 1,
                                        "column": 74
                                    },
                                    "end": {
                                        "line": 1,
                                        "column": 80
                                    }
                                },
                                "range": [
                                    74,
                                    80
                                ],
                                "value": "&#x;",
                                "raw": "\"&#x;\""
                            }
                        }
                    ],
                    "name": {
                        "type": "JSXIdentifier",
                        "loc": {
                            "start": {
                                "line": 1,
                                "column": 1
                            },
                            "end": {
                                "line": 1,
                                "column": 2
                            }
                        },
                        "range": [
                            1,
                            2
                        ],
                        "name": "a"
                    },
                    "selfClosing": true
                },
                "closingElement": null,
                "children": []
            }
        }
    ],
    "sourceType": "script",
    "tokens": [
        {
            "type": "Punctuator",
            "value": "<",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 0
                },
                "end": {
                    "line": 1,
                    "column": 1
                }
            },
            "range": [
                0,
                1
            ]
        },
        {
            "type": "JSXIdentifier",
            "value": "a",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 1
                },
                "end": {
                    "line": 1,
                    "column": 2
                }
            },
            "range": [
                1,
                2
            ]
        },
        {
            "type": "JSXIdentifier",
            "value": "b",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 3
                },
                "end": {
                    "line": 1,
                    "column": 4
                }
            },
            "range": [
                3,
                4
            ]
        },
        {
            "type": "Punctuator",
            "value": "=",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 4
                },
                "end": {
                    "line": 1,
                    "column": 5
                }
            },
            "range": [
                4,
                5
            ]
        },
        {
            "type": "Punctuator",
            "value": "{",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 5
                },
                "end": {
                    "line": 1,
                    "column": 6
                }
            },
            "range": [
                5,
                6
            ]
        },
        {
            "type": "String",
            "value": "\" \"",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 6
                },
                "end": {
                    "line": 1,
                    "column": 9
                }
            },
            "range": [
                6,
                9
            ]
        },
        {
            "type": "Punctuator",
            "value": "}",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 9
                },
                "end": {
                    "line": 1,
                    "column": 10
                }
            },
            "range": [
                9,
                10
            ]
        },
        {
            "type": "JSXIdentifier",
            "value": "c",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 11
                },
                "end": {
                    "line": 1,
                    "column": 12
                }
            },
            "range": [
                11,
                12
            ]
        },
        {
            "type": "Punctuator",
            "value": "=",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 12
                },
                "end": {
                    "line": 1,
                    "column": 13
                }
            },
            "range": [
                12,
                13
            ]
        },
        {
            "type": "JSXText",
            "value": "\" \"",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 13
                },
                "end": {
                    "line": 1,
                    "column": 16
                }
            },
            "range": [
                13,
                16
            ]
        },
        {
            "type": "JSXIdentifier",
            "value": "d",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 17
                },
                "end": {
                    "line": 1,
                    "column": 18
                }
            },
            "range": [
                17,
                18
            ]
        },
        {
            "type": "Punctuator",
            "value": "=",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 18
                },
                "end": {
                    "line": 1,
                    "column": 19
                }
            },
            "range": [
                18,
                19
            ]
        },
        {
            "type": "JSXText",
            "value": "\"&amp;\"",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 19
                },
                "end": {
                    "line": 1,
                    "column": 26
                }
            },
            "range": [
                19,
                26
            ]
        },
        {
            "type": "JSXIdentifier",
            "value": "e",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 27
                },
                "end": {
                    "line": 1,
                    "column": 28
                }
            },
            "range": [
                27,
                28
            ]
        },
        {
            "type": "Punctuator",
            "value": "=",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 28
                },
                "end": {
                    "line": 1,
                    "column": 29
                }
            },
            "range": [
                28,
                29
            ]
        },
        {
            "type": "JSXText",
            "value": "\"id=1&group=2\"",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 29
                },
                "end": {
                    "line": 1,
                    "column": 43
                }
            },
            "range": [
                29,
                43
            ]
        },
        {
            "type": "JSXIdentifier",
            "value": "f",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 44
                },
                "end": {
                    "line": 1,
                    "column": 45
                }
            },
            "range": [
                44,
                45
            ]
        },
        {
            "type": "Punctuator",
            "value": "=",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 45
                },
                "end": {
                    "line": 1,
                    "column": 46
                }
            },
            "range": [
                45,
                46
            ]
        },
        {
            "type": "JSXText",
            "value": "\"&#123456789\"",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 46
                },
                "end": {
                    "line": 1,
                    "column": 59
                }
            },
            "range": [
                46,
                59
            ]
        },
        {
            "type": "JSXIdentifier",
            "value": "g",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 60
                },
                "end": {
                    "line": 1,
                    "column": 61
                }
            },
            "range": [
                60,
                61
            ]
        },
        {
            "type": "Punctuator",
            "value": "=",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 61
                },
                "end": {
                    "line": 1,
                    "column": 62
                }
            },
            "range": [
                61,
                62
            ]
        },
        {
            "type": "JSXText",
            "value": "\"&#123*;\"",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 62
                },
                "end": {
                    "line": 1,
                    "column": 71
                }
            },
            "range": [
                62,
                71
            ]
        },
        {
            "type": "JSXIdentifier",
            "value": "h",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 72
                },
                "end": {
                    "line": 1,
                    "column": 73
                }
            },
            "range": [
                72,
                73
            ]
        },
        {
            "type": "Punctuator",
            "value": "=",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 73
                },
                "end": {
                    "line": 1,
                    "column": 74
                }
            },
            "range": [
                73,
                74
            ]
        },
        {
            "type": "JSXText",
            "value": "\"&#x;\"",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 74
                },
                "end": {
                    "line": 1,
                    "column": 80
                }
            },
            "range": [
                74,
                80
            ]
        },
        {
            "type": "Punctuator",
            "value": "/",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 81
                },
                "end": {
                    "line": 1,
                    "column": 82
                }
            },
            "range": [
                81,
                82
            ]
        },
        {
            "type": "Punctuator",
            "value": ">",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 82
                },
                "end": {
                    "line": 1,
                    "column": 83
                }
            },
            "range": [
                82,
                83
            ]
        },
        {
            "type": "Punctuator",
            "value": ";",
            "loc": {
                "start": {
                    "line": 1,
                    "column": 83
                },
                "end": {
                    "line": 1,
                    "column": 84
                }
            },
            "range": [
                83,
                84
            ]
        }
    ]
};