module.exports = {
    "index": 14,
    "lineNumber": 1,
    "column": 15,
    "message": "Unexpected token \"app\""
};